```html
<script>{% include_relative require1k.min.js %}</script>
```
