module.exports = ["Apple", "Banana", "Cherry"]
