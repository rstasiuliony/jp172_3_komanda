var fruits = require("./fruits");
var container = document.getElementById("container");

container.textContent = fruits.join(", ");
