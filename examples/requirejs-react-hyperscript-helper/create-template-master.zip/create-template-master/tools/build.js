{
    "appDir": "../www",
    "mainConfigFile": "../www/app.js",
    "dir": "../www-built",
    "modules": [
        {
            "name": "app"
        }
    ]
}
